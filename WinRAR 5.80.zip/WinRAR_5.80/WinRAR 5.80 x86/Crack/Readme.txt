- Install app
- Copy rarreg.key to install dir

